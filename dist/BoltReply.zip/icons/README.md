# Icons Directory

This directory should contain the Chrome extension icons in the following sizes:
- icon16.png (16x16)
- icon32.png (32x32) 
- icon48.png (48x48)
- icon128.png (128x128)

You can create these icons using any image editor or icon generator.
The icons should represent your extension's functionality and be visually appealing.
